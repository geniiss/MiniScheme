
class Nothing(Exception):
    def __init__(self, missatge):
        self.missatge = missatge
